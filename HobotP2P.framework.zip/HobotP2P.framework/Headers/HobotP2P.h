//
//  HobotP2P.h
//  HobotP2P
//
//  Created by 程烈 on 20/06/2017.
//  Copyright © 2017 Hobot. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HobotP2P.
FOUNDATION_EXPORT double HobotP2PVersionNumber;

//! Project version string for HobotP2P.
FOUNDATION_EXPORT const unsigned char HobotP2PVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HobotP2P/PublicHeader.h>

#import <HobotP2P/ARDAppClient.h>
